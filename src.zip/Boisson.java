public class Boisson {

    private double taux;
    private double quantite;
    private String nom;
    private int id;

}
