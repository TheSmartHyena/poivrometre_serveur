import com.google.gson.internal.$Gson$Types;

public class Compte {

    private double poids;
    private boolean sexe;
    private String mdp, pseudo;

    public Compte(double poids, boolean sexe, String mdp, String pseudo){
        this.poids = poids;
        this.sexe = sexe;
        this.mdp = mdp;
        this.pseudo = pseudo;
    }

    public double getPoids(){
        return this.poids;
    }

    public boolean getSexe(){
        return this.sexe;
    }

    public String getMdp(){
        return this.mdp;
    }

    public String getPseudo(){
        return this.pseudo;
    }

}
