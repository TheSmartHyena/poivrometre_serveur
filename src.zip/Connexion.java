public class Connexion {
    private String pseudo, mdp;

    public String getPseudo(){
        return this.pseudo;
    }

    public String getMdp(){
        return this.mdp;
    }
}
