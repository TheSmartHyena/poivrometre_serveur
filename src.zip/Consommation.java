import java.sql.Time;
import java.sql.Timestamp;

public class Consommation {

    private String pseudo;
    private int boisson;
    private Timestamp heure;

}
