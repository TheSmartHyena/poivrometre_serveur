public class Json_conso {

    private String key;
    private int id_boisson;

    public int getId(){
        return this.id_boisson;
    }
    public String getKey() { return this.key; }

}
