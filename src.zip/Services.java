
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import com.google.gson.*;

import java.sql.*;
import java.util.Date;

@Path("/services")
public class Services {

    static Connection con;

    @GET
    @Path("/test")
    public String test(){
        return "test";
    }

    @POST
    @Path("/connect")
    @Consumes(MediaType.APPLICATION_JSON)
    public String connect(String json){
        Gson creator = new Gson();
        Connexion connexion = creator.fromJson(json, Connexion.class);
        try {
            Connection con = Services.getCO();

            PreparedStatement prepared2 = con.prepareStatement("SELECT pseudo FROM Compte where pseudo=? and pwd=?");
            prepared2.setString(1,connexion.getPseudo());
            prepared2.setString(2,connexion.getMdp());
            ResultSet rs2 = prepared2.executeQuery();
            String key = "";
            if(rs2.next()) {
                key = Services.getAlphaNumericString(20);
                PreparedStatement prepared = con.prepareStatement("insert into Utilisateur values (?,?)");
                prepared.setString(1,connexion.getPseudo());
                prepared.setString(2,key);
                prepared.execute();
                rs2.close();
                return key;
            }
            rs2.close();
            return "";
        }catch (Exception e){
            e.printStackTrace();
            return "";
        }
    }

    @POST
    @Path("/conso")
    @Consumes(MediaType.APPLICATION_JSON)
    public void addconso(String json){
        Gson creator = new Gson();
        Json_conso conso = creator.fromJson(json, Json_conso.class);

        Date date = new Date();
        try {
            Connection con = Services.getCO();

            PreparedStatement prepared = con.prepareStatement("SELECT pseudo FROM Utilisateur WHERE IDUser =?");
            prepared.setString(1,conso.getKey());
            ResultSet rs = prepared.executeQuery();
            rs.next();
            String pseudo  = rs.getString("pseudo");
            rs.close();

            PreparedStatement prepared2 = con.prepareStatement("insert into Consommation values (?,?,?)");
            prepared2.setString(1,pseudo);
            prepared2.setInt(2,conso.getId());
            prepared2.setTimestamp(3,new Timestamp(date.getTime()));
            prepared2.execute();
        }catch(Exception e){
            e.printStackTrace();
        }
    }

    @POST
    @Path("/create")
    @Consumes(MediaType.APPLICATION_JSON)
    public boolean create(String json) {
        Gson creator = new Gson();
        Compte compte = creator.fromJson(json, Compte.class);
        try {
            Connection con = Services.getCO();
            Statement t = con.createStatement();
            PreparedStatement prepared = con.prepareStatement("insert into Compte (pseudo,pwd,sexe,poids) values (?,?,?,?)");
            prepared.setString(1,compte.getPseudo());
            prepared.setString(2,compte.getMdp());
            prepared.setBoolean(3,compte.getSexe());
            prepared.setDouble(4, compte.getPoids());
            prepared.execute();
            return true;
        } catch (Exception e){
            e.printStackTrace();
            return false;
        }
    }

    @POST
    @Path("/taux")
    //@Consumes(MediaType.APPLICATION_JSON)
    public double taux(String json) {
        Gson creator = new Gson();
        Json_conso compte = creator.fromJson(json, Json_conso.class);
        try {
            Connection con = Services.getCO();
            PreparedStatement prepared = con.prepareStatement("SELECT pseudo FROM Utilisateur WHERE IDUser =?");
            prepared.setString(1,compte.getKey());
            ResultSet rs = prepared.executeQuery();
            rs.next();
            String pseudo = rs.getString(1);
            rs.close();

            prepared = con.prepareStatement("SELECT sexe, poids FROM Compte WHERE pseudo =?");
            prepared.setString(1,pseudo);
            rs = prepared.executeQuery();
            rs.next();
            boolean sexe = rs.getBoolean(1);
            double poids = rs.getDouble(2);
            rs.close();

            prepared = con.prepareStatement("SELECT id_boisson, heure FROM Consommation WHERE pseudo =? order by heure asc");
            prepared.setString(1,pseudo);
            rs = prepared.executeQuery();
            PreparedStatement prep;
            ResultSet rs2;
            double taux = 0.0;
            double tmp;
            Timestamp time = null;
            Date d = new Date();
            int temp;
            while(rs.next()) {
                prep = con.prepareStatement("SELECT quantite, taux FROM Boisson WHERE id_boisson =?");
                prep.setInt(1,rs.getInt(1));
                rs2 = prep.executeQuery();
                rs2.next();
                tmp = (rs2.getDouble(1)*(rs2.getDouble(2)/100)*0.8) / (poids * 0.7);

                taux += tmp;
                if(time != null) {
                    temp = (int) ((rs.getTimestamp(2).getTime() - time.getTime()) / 1000);
                    temp = temp / 300;
                    taux -= 0.01*temp;
                }
                time = rs.getTimestamp(2);
            }
            rs.close();

            if(time != null){
                temp = (int) ((d.getTime() - time.getTime())/1000);
                temp = temp / 300;
                taux -= 0.01*temp;
            }

            if(taux < 0)
                return 0;
            return taux;
        } catch (Exception e){
            e.printStackTrace();
            return -1.0;
        }
    }

    static Connection getCO() throws ClassNotFoundException, SQLException {
        if(Services.con == null) {
            Class.forName("com.mysql.jdbc.Driver");
            Services.con = DriverManager.getConnection("jdbc:mysql://mysql-poivrometre.alwaysdata.net:3306/poivrometre_poivrometre", "199493_admin", "gestiondeprojet_poivrometre");
        }
        return Services.con;
    }

    static String getAlphaNumericString(int n)
    {

        // chose a Character random from this String
        String AlphaNumericString = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
                + "0123456789"
                + "abcdefghijklmnopqrstuvxyz";

        // create StringBuffer size of AlphaNumericString
        StringBuilder sb = new StringBuilder(n);

        for (int i = 0; i < n; i++) {

            // generate a random number between
            // 0 to AlphaNumericString variable length
            int index
                    = (int)(AlphaNumericString.length()
                    * Math.random());

            // add Character one by one in end of sb
            sb.append(AlphaNumericString
                    .charAt(index));
        }

        return sb.toString();
    }
}